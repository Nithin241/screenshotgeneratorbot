from .screenshotbot import ScreenShotBot

if __name__ == "__main__":
    ScreenShotBot().run()
